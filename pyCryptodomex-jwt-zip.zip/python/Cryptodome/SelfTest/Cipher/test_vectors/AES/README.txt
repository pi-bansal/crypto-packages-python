Files downloaded from the NIST website on November 8, 2015 as:

* http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
* http://csrc.nist.gov/groups/STM/cavp/documents/aes/aesmct.zip
* http://csrc.nist.gov/groups/STM/cavp/documents/aes/aesmmt.zip

And on December 16, 2015 as:

* http://csrc.nist.gov/groups/STM/cavp/documents/mac/gcmtestvectors.zip
